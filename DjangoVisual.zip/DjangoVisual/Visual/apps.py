from django.apps import AppConfig


class VisualConfig(AppConfig):
    name = 'Visual'
