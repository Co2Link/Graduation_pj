from django.apps import AppConfig


class MainConfig(AppConfig):
    name = 'my_main'
