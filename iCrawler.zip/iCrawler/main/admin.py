from django.contrib import admin
from main.models import ScrapyItem

admin.site.register(ScrapyItem)
# Register your models here.
